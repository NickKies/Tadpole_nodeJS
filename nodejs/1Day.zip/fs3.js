var fs = require('fs');

fs.readFile('text.txt', 'utf8', function(err, data){
    if(err){
        console.log(err);
    }else{
        console.log(data);
    }
});

fs.writeFile('text3.txt', 'Hello World .. !', 'utf8', function(err){
    if(err){
        console.log(err);
    }else{
        console.log('File Write Complete!');
    }
})
