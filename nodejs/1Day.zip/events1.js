var events = require('events');
var eventEmitter = new events.EventEmitter();
var connectHandler = function connected(){ // 3
    console.log("Connection Successful"); // 4
    eventEmitter.emit("data_received"); // 5
}
eventEmitter.on('connection', connectHandler);  // 2
eventEmitter.on('data_received', function(){    // 6
    console.log("Data Received");
});
eventEmitter.emit('connection');    // 1
console.log("Program has ended");   // 7