var fs = require('fs');
try {   // 동기식 파일 읽는 예외 처리
    var data = fs.readFileSync('text.txt', 'utf8');
    console.log(data);
}catch(e){
    console.log(e);
}
try { // 동기식 파일 쓰는 예외 처리
    fs.writeFileSync('text1.txt', 'Hello World ...!', 'utf8');
    console.log('File write Complete');
}catch(e) {
    console.log(e);
}