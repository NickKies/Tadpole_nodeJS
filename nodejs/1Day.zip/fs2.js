var fs = require('fs');
var data = 'Hello World ... ! ';

fs.writeFile('text2.txt', data, 'utf8', function(err){ // 비동기 쓰기
    console.log('write file async complete !');
});

fs.writeFileSync('text3.txt', data, 'utf8'); // 동기 쓰기
console.log('write file sync complete !');

