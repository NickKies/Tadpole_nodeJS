var fs = require('fs');

var text = fs.readFileSync('text.txt', 'utf8'); // 동기식
console.log(text);

fs.readFile('text.txt', 'utf8', function(err, data){ // 비동기식
    console.log(data);
});
