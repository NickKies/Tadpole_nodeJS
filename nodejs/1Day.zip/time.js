console.time('start'); // 시간 측정을 시작합니다.

var result = 1;
for(var i = 1; i <= 10; i++){
    result *= i;
    // result = result * i;
    // result = 1 * 1; -> 1
    // result = 1 * 2; -> 2
    // result = 2 * 3; -> 6
    // result = 6 * 4; -> 24
    // result = 24 * 5; -> 120
    // ...
}
console.log('결과 : ' + result);
console.timeEnd('start'); // start라는 이름의 시간 측정을 완료

