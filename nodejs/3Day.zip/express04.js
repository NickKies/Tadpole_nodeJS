var http = require('http');
var express = require('express');
var app = express();

app.use(function(req, res) {
    var name = req.param('name');
    var gender = req.param('gender');
    res.send('<h1>' + name + '-' + gender + '</h1>');
});

http.createServer(app).listen(3000, function() {
    console.log('server running at https://localhost:3000');
});