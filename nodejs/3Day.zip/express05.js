var http = require('http');
var express = require('express');
var app = express();
app.use(function(req, res, next) {
    console.log('첫 번째 미들웨어');
    res.a = 'a';
    req.b = 'b';
    next();
});
app.use(function(req, res, next) {
    console.log('두 번째 미들웨어');
    res.send('<h1> res.a = ' + res.a + ' req.b = ' + req.b + '</h1>');
});
http.createServer(app).listen(3000, function(){
    console.log('server running at https://localhost:3000');
});