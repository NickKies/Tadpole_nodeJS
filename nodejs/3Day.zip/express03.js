var http = require('http');
var express = require('express');
var app = express();

app.use(function(req, res) {
    var agent = req.header('User-Agent');
    console.log(req.headers);
    console.log('-----------------------------------------------------------');
    console.log(agent);
    res.send(200);
});

http.createServer(app).listen(3000, function() {
    console.log('server running at https://localhost:3000');
});