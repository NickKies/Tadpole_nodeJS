var express = require('express');
var app = express();
app.use(express.static('public'));  // 가상경로(리소스)
app.get('/', function(req, res){
    res.send('Hello home page');
});
app.get('/fruit', function(req, res){
    res.send('Hello fruit, <img src="/fruit.png">')
})
app.get('/login', function(req, res){
    res.send('<h1>Login please</h1>');
});
app.listen(3000, function(){
    console.log('Conneted 3000 port!');
});